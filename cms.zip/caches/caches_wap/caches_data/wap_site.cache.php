<?php
return array (
  1 => 
  array (
    'siteid' => '1',
    'sitename' => 'PHPCMS手机门户',
    'logo' => '/statics/images/wap/wlogo.gif',
    'domain' => '',
    'setting' => 'array (
  \'listnum\' => \'10\',
  \'thumb_w\' => \'220\',
  \'thumb_h\' => \'0\',
  \'c_num\' => \'1000\',
  \'index_template\' => \'index\',
  \'category_template\' => \'category\',
  \'list_template\' => \'list\',
  \'show_template\' => \'show\',
)',
    'status' => '1',
  ),
);
?>