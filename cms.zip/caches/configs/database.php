<?php

return array (
	'default' => array (
		'hostname' => 'qdm153622320.my3w.com',
		'port' => 3306,
		'database' => 'qdm153622320_db',
		'username' => 'qdm153622320',
		'password' => '3546425zj',
		'tablepre' => 'cms_',
		'charset' => 'utf8',
		'type' => 'mysqli',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		),
);

?>