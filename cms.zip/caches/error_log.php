<?php exit;?>03-06 16:55:08 | 2 | Invalid argument supplied for foreach() | phpcms/modules/wap/functions/global.func.php | 63
