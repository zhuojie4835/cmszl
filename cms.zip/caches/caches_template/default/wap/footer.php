<?php defined('IN_PHPCMS') or exit('No permission resources.'); ?>    <div class="tc"><a href="#hd"><img src="<?php echo IMG_PATH;?>wap/top.gif" alt="" width="46" height="16" /></a></div>
    <div class="ft">
    	<a href="<?php echo WAP_SITEURL;?>"><?php echo $WAP['sitename'];?></a>-<a href="<?php echo APP_PATH;?>index.php?m=wap&amp;c=index&amp;a=maps">导航</a>
    </div>
</div>
</body>
</html>