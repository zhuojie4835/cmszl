<?php
return array (
  1 => 
  array (
    'siteid' => '1',
    'name' => '大锅网',
    'dirname' => '',
    'domain' => 'http://www.vw87china.com/',
    'site_title' => '大锅网',
    'keywords' => '中国力量，中国文化',
    'description' => '中国力量，中国文化',
    'release_point' => '',
    'default_style' => 'default',
    'template' => 'default',
    'setting' => '{"upload_maxsize":"2048","upload_allowext":"jpg|jpeg|gif|bmp|png|doc|docx|xls|xlsx|ppt|pptx|pdf|txt|rar|zip|swf","watermark_enable":"1","watermark_minwidth":"300","watermark_minheight":"300","watermark_img":"statics\\/images\\/water\\/\\/mark.png","watermark_pct":"85","watermark_quality":"80","watermark_pos":"9"}',
    'uuid' => '8f7b0a1a-024a-11e7-b448-00163e002e1f',
    'url' => 'http://www.vw87china.com/',
  ),
);
?>