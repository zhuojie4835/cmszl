CREATE TABLE `$tablename` (
  `userid` MEDIUMINT(8) unsigned NOT NULL,
   UNIQUE KEY  (`userid`)
) TYPE=MyISAM;