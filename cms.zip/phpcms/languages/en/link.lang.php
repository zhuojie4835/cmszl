<?php
$LANG['link'] 							=	'Partner Links';
$LANG['link_add'] 						=	'Add';
$LANG['link_name'] 						= 	'Site name';
$LANG['logo'] 							= 	'LOGO';
$LANG['url'] 							= 	'URL';
$LANG['link_type'] 						= 	'Type';
$LANG['typeid'] 						= 	'Category';
$LANG['status'] 						= 	'Status';
$LANG['type_id'] 						= 	'Category ID';

$LANG['type_name'] 						= 	'Category Name';
$LANG['list_type'] 						= 	'Classification';
$LANG['link_type_listorder'] 			=	'Priority';


$LANG['web_description'] 				= 	'Description';
$LANG['type_description'] 				= 	'Classification description';

$LANG['username'] 						= 	'Contact person';
$LANG['elite']						 	= 	'Promote';
$LANG['passed'] 						= 	'Approval';

$LANG['setting_updates_successful']		=	'Updated successfully';
$LANG['input_not_space'] 				=	'Please input content WITHOUT any spaces';
$LANG['remove_all_selected']			=	'Remove all selected';

$LANG['sitename_noempty']				=	' is Required';
$LANG['siteurl_not_empty']				=	' is Required';
$LANG['typename_noempty']				=	' is Required';
$LANG['add_success']					=	'Submitted successfully, returning';
$LANG['suspend_application']			=	'Suspended application, returning';

$LANG['link_exit']						=	'Partner link does not exist';
$LANG['linktype_exit']					=	'Classification does not exist';
$LANG['all_linktype']					=	'All classification';
$LANG['all']							=	'All';

$LANG['word_link']						=	'Text link';
$LANG['logo_link']						=	'Logo link';
$LANG['before_select_operations']		=	'Please select';

$LANG['yes']							=	'Yes';
$LANG['no']								=	'No';

$LANG['link_list'] 						= 	'Partner Links';
$LANG['go_website']						=	'Go to';
$LANG['pass_check']						=	'Approval';
$LANG['pass_or_not']					=	'Pass the review';
$LANG['audit']							=	'Review';
$LANG['passed']							=	'Approval';
$LANG['move_success']					=	'Moved successfully';
$LANG['application_or_not']				=	'Allow to apply';
$LANG['code_or_not']					=	'Enable auth code';
$LANG['choose_true_type']				=	'Please select correct classification';
$LANG['application_links']				=	'Partner Link application';
$LANG['link_onerror']					=	'Format should be http://www.phpcms.cn/';
?>