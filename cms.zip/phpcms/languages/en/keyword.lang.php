<?php
$LANG['keyword_manage'] = '';
$LANG['keyword_name'] = 'Keywords';
$LANG['remove_all_selected']			=	'Remove all selected restricted words';
?>